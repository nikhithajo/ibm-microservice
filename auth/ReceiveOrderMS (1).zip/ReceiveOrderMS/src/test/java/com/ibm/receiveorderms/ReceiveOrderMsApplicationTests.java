package com.ibm.receiveorderms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReceiveOrderMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
