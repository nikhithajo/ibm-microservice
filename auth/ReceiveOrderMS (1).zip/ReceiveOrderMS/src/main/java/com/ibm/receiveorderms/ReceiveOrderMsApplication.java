package com.ibm.receiveorderms;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReceiveOrderMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReceiveOrderMsApplication.class, args);
	}

}
