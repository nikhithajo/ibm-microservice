package com.ibm.authenticationms.utility;

public class TestString {

	/*
	 * public static void main(String[] args) { String s =
	 * "{itemCode=1234, quantity=23}";
	 * 
	 * }
	 */

}
